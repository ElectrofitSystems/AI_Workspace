---
name: organizer-teams-reorganization
description: Riorganizza in modo controllato i Team aziendali, un Team o canale alla volta, conservando gli originali e richiedendo conferme umane.
---

# Organizer Teams Reorganization

ModalitÃ  opzionale, lunga e dipendente dai moderatori.

1. Selezionare un Team o canale.
2. Inventariare in sola lettura fino all'ultima sottocartella.
3. Chiedere la funzione di ogni cartella. Le ipotesi non sono regole.
4. Proporre la struttura senza modificarla.
5. Copiare il materiale pilota in 00_Inbox lasciando intatto l'originale.
6. Applicare Inbox, Review, Approved e destinazione.
7. Migliorare le proposte senza rimuovere le approvazioni.
8. Dopo la verifica, chiedere separatamente se eliminare l'originale.
9. Senza approvazione o destinazione certa, conservarlo.
10. Lavorare a blocchi e produrre un riepilogo.
11. Proporre una revisione mensile, trimestrale, semestrale o manuale.
