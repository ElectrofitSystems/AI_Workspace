---
name: organizer-power-automate-setup
description: Crea, prova o ripara i flussi Power Automate necessari a Organizer usando browser o Computer Use sotto supervisione umana.
---

# Organizer Power Automate Setup

- Ispezionare flussi, connessioni e cartelle esistenti.
- Organizer fornisce sorgente, file, destinazione e decisione; Power Automate esegue.
- Non usare Power Automate per la schedule interna di 24 ore.
- Il trigger di risveglio appartiene all'integrazione Teams.
- Computer Use Ã¨ facoltativo e supervisionato.

Predisporre:

1. copia dalla chat Operations a 00_Inbox;
2. richiesta e risposta Approvals;
3. trasferimento da 02_Approved alla destinazione;
4. cancellazione dopo approvazione esplicita;
5. scrittura in Logs;
6. gestione errori, retry limitati e idempotenza.

Creare un flusso alla volta, testarlo con materiale non sensibile e attivarlo solo dopo approvazione umana.
