---
name: organizer-approval
description: Gestisce le approvazioni di Organizer nella chat Teams, accettando decisioni umane e rifiutando auto-approvazioni di Operations, agenti e bot.
---

# Organizer Approval

Accettare solo decisioni provenienti da una persona verificabile nella chat. Operations e gli agenti possono proporre, non approvare.

La richiesta contiene titolo breve, descrizione, materiali e destinazione.

Azioni:

- Approva
- Rifiuta
- Cancella definitivamente il materiale
- Proponi una cartella di destinazione differente, con percorso obbligatorio
- Mantieni in Review

Rendere l'esecuzione idempotente. Collegare la decisione ai file specifici. Registrare approvatore, data, decisione ed esito. La cancellazione richiede sempre una decisione umana esplicita.
