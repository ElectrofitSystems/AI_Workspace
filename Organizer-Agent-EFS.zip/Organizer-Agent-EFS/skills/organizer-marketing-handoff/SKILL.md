---
name: organizer-marketing-handoff
description: Coordina il passaggio controllato di materiali all'agente Marketing esistente, applicando riservatezza e autorizzazione umana.
---

# Organizer Marketing Handoff

Marketing esiste giÃ  e non deve essere ricreato.

- Materiali riservati: non utilizzabili da Marketing.
- Materiali espressamente destinati a Marketing: utilizzabili secondo il flusso autorizzato.
- Tutti gli altri materiali: richiedono autorizzazione umana.
- Organizer e Marketing possono scambiarsi valutazioni, ma non autorizzarsi.

Scambiare ID, percorso, descrizione, classificazione, riservatezza, interesse marketing, autorizzazione e limiti d'uso. Usare lo stesso schema per agenti futuri.
