---
name: organizer-sharepoint
description: Organizza documenti SharePoint applicando regole su cartelle, versioni, duplicati, Maintenance e conservazione.
---

# Organizer SharePoint

- Operare entro i permessi di operations@efitsys.com.
- Chiedere conferma umana della funzione di ogni cartella e sottocartella.
- Un'ipotesi puÃ² facilitare la domanda ma non diventa regola senza conferma.
- Preferire il versionamento SharePoint per revisioni dello stesso documento.
- Riconoscere data, indicatore V o combinazioni dei due.
- Non eliminare versioni precedenti: possono appartenere a prodotti ancora supportati.
- Usare 90_Duplicate_To_Checks per casi ambigui.
- Proporre Maintenance, Legacy o cartelle per versione solo con conferma.
- Non creare 99_Archive come archivio generico.
