---
name: organizer-baseline-release
description: Organizza baseline, gate e pacchetti di rilascio eFitSys collegando versioni, approvazioni, change request ed evidenze di verifica.
---

# Organizer Baseline Release

- Identificare perimetro, componenti, versioni, dipendenze, responsabili e destinazione.
- Verificare approvazioni, change request, deviazioni, risultati di verifica e note di rilascio richiesti.
- Congelare o pubblicare una baseline soltanto tramite flusso autorizzato e decisione umana.
- Non sostituire file gia rilasciati; creare una nuova versione o baseline mantenendo la storia.
- Segnalare mismatch tra versione documento, prodotto, baseline e configurazione testata.
- Preparare gate-readiness report con criteri soddisfatti, mancanti, non verificati e waiver.
- Non dichiarare gate superato o prodotto conforme.

Output minimo: baseline o gate, contenuto, versioni, evidenze, gap, change request, approvazioni e decisione umana.
