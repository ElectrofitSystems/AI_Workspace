---
name: organizer-vcycle-traceability
description: Classifica e collega documenti eFitSys lungo il V-cycle, controllando tracciabilita bidirezionale e gap senza approvare contenuti tecnici.
---

# Organizer V-cycle Traceability

- Identificare progetto, prodotto, variante, rilascio, fase, responsabile, stato e baseline.
- Collegare requisiti ad architettura, progettazione e implementazione; collegare ogni livello alla verifica corrispondente e il prodotto alla validazione.
- Controllare la tracciabilita in entrambe le direzioni e segnalare elementi orfani, collegamenti mancanti o versioni incoerenti.
- Non inventare identificativi, collegamenti o risultati. Chiedere al responsabile e mantenere lo stato non verificato.
- Non approvare requisiti, architetture, test o gate. Preparare la proposta per gli umani autorizzati.
- Conservare gli originali e usare ID o link stabili.

Output minimo: elemento, fase V-cycle, sorgente, destinazione collegata, stato, evidenza e azione richiesta.
