---
name: organizer-installation
description: Installa o riconfigura Organizer Agent EFS, inclusi progetto Codex, canale Operations, chat approvazioni, cartelle, identitÃ , trigger Teams, plugin e test.
---

# Organizer Installation

1. Chiedere se usare un progetto Codex dedicato o esistente.
2. Verificare Team Administrator, canale Operations, cartelle, flussi e permessi giÃ  presenti.
3. Proporre 00_Inbox, 01_Review, 02_Approved, 90_Duplicate_To_Checks, Logs e Configuration; spiegarne lo scopo e chiedere conferma.
4. Registrare la chat unica di moderazione e approvazione e le identitÃ  non umane.
5. Collegare Teams, SharePoint e OneNote. Computer Use resta facoltativo e supervisionato.
6. Configurare un trigger Teams per nuovi materiali, risposte dell'autore e decisioni umane.
7. Usare organizer-power-automate-setup per costruire i flussi.
8. Eseguire un test completo con materiale non sensibile.
9. Salvare configurazione e risultati in Configuration.
10. Proporre la riorganizzazione senza avviarla automaticamente.

operations@efitsys.com e gli agenti non possono approvare.
