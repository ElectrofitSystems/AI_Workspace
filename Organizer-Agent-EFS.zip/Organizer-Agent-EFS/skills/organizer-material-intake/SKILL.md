---
name: organizer-material-intake
description: Gestisce i nuovi materiali ricevuti da Operations, inclusi chiarimenti, schedule interna di 24 ore, classificazione e passaggio da Inbox a Review.
---

# Organizer Material Intake

1. Assegnare un ID e registrare autore, messaggio, allegati e origine.
2. Copiare in 00_Inbox senza alterare l'originale.
3. Fare all'autore tutte le domande necessarie.
4. Se restano dubbi, creare una schedule interna di 24 ore e salvarne l'ID.
5. Il trigger Teams risveglia Organizer sulle risposte. Se i dubbi sono risolti, cancellare subito la schedule.
6. Alla scadenza rileggere lo stato: se restano dubbi, interrogare la chat delle approvazioni.
7. I moderatori non hanno scadenza.
8. Solo dopo la decisione di conservare e il completamento delle informazioni, spostare in 01_Review.

La schedule appartiene a Organizer, non a Power Automate. Deve essere specifica, idempotente e cancellabile.

## Escalation

La richiesta ai moderatori contiene materiali ricevuti, autore, classificazione proposta, descrizione proposta, dubbi aperti e decisione richiesta: conservare o cestinare.
