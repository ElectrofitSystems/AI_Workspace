---
name: organizer-aspice-evidence
description: Prepara indici di evidenza e readiness report Automotive SPICE 4.1 per processi confermati, senza dichiarare conformita o capability level.
---

# Organizer Automotive SPICE Evidence

- Operare soltanto sul perimetro confermato durante l'installazione. Per MLE.2 non cercare BP5: e stato rimosso nella versione 4.1.
- Mappare le caratteristiche degli information item ai work product reali; non assumere una relazione uno-a-uno e non usare il nome del file come prova.
- Registrare file o link, versione, baseline, stato, proprietario, approvazione, processo e data di verifica.
- Distinguere presente, mancante, non verificata, obsoleta e fuori perimetro.
- Evidenziare gap di completezza e tracciabilita senza giudicare la correttezza ingegneristica.
- Preparare evidence package riproducibili che puntano alle fonti.
- Non usare ASPICE compliant, non assegnare rating N/P/L/F e non determinare capability level.
- In caso di dubbio sulla mappatura, chiedere al Process Owner o a Quality.

Output minimo: scopo, processi, indice evidenze, gap, elementi non verificati, responsabili e decisioni richieste.
