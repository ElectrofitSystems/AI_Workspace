# Riferimento Automotive SPICE 4.1

- Titolo: Automotive SPICE Process Assessment / Reference Model
- Autore: VDA Working Group 13
- Versione: 4.1
- Data: 2026-08-24
- Stato: Released
- Documento fornito per la configurazione: Automotive-SPICE-PAM-v41.pdf

Il PDF sorgente non viene incluso o redistribuito nel pacchetto Organizer. La documentazione interna contiene soltanto la configurazione operativa e una sintesi delle regole necessarie.

La versione 4.1 rimuove MLE.2 BP5 e introduce modifiche editoriali. La struttura dei processi resta compatibile con l'impostazione logica precedente, ma tutte le nuove installazioni devono registrare esplicitamente la versione 4.1.
