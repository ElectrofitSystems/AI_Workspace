# Mappa iniziale Automotive SPICE 4.0

Configurazione iniziale da confermare con Process Owner e Quality. Non rappresenta conformita.

| Area | Processi iniziali | Materiali tipici |
|---|---|---|
| System engineering | SYS.1-SYS.5 | Requisiti, architettura, integrazione e verifica |
| Software engineering | SWE.1-SWE.6 | Requisiti, architettura, design, codice e test |
| Hardware engineering | HWE.1-HWE.4 | Requisiti, design e verifiche hardware |
| Management | MAN.3, MAN.5 | Piano, stato, responsabilita e rischi |
| Support | SUP.1, SUP.8, SUP.9, SUP.10 | Qualita, configurazione, problemi e modifiche |
| Product release | SPL.2 | Pacchetto approvato, note ed evidenza di consegna |

Il perimetro effettivo, i work product equivalenti e le responsabilita vanno registrati in Configuration.
