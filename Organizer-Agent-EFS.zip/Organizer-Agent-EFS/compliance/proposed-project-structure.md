# Prima struttura proposta per progetto

Prima infarinatura da discutere durante l'installazione. Organizer deve chiedere ai moderatori la funzione di ogni cartella prima di adottarla.

    <Project>/
    |-- 00_INDEX/
    |-- 01_MAN_Management/
    |-- 02_REF_Reference_Documentation/
    |-- 03_SYS_System_Engineering/
    |-- 04_DEV_Development/
    |   +-- <discipline_da_confermare>/
    |-- 05_VER_Verification_and_Validation/
    |   |-- Plans/
    |   |-- Procedures/
    |   |-- Results/
    |   +-- Coverage/
    |-- 06_SUP_Support_Processes/
    |   |-- SUP.1_Quality_Assurance/
    |   |-- SUP.8_Configuration_Management/
    |   |-- SUP.9_Problem_Resolution/
    |   +-- SUP.10_Change_Request_Management/
    |-- 07_SPL.2_Releases/
    +-- 99_Archive/  [opzionale]

| Cartella | Contenuto e collegamento |
|---|---|
| 00_INDEX | Responsabile, perimetro, repository, piano e configurazione corrente |
| 01_MAN_Management | Pianificazione, responsabilita e rischi: MAN.3, MAN.5 |
| 02_REF_Reference_Documentation | Datasheet, cataloghi e manuali ricevuti; REF e interno |
| 03_SYS_System_Engineering | Requisiti e architettura: SYS.1, SYS.2, SYS.3 |
| 04_DEV_Development | Progettazione e implementazione per disciplina; DEV e interno |
| 05_VER_Verification_and_Validation | Piani, procedure, risultati e copertura; VER e interno |
| 06_SUP_Support_Processes | SUP.1, SUP.8, SUP.9, SUP.10 |
| 07_SPL.2_Releases | Pacchetti approvati, note ed evidenza di consegna |
| 99_Archive | Solo storico identificato; opzionale e non creato automaticamente |

MAN, SYS, SUP e SPL.2 richiamano Automotive SPICE. REF, DEV e VER sono codici organizzativi interni. La struttura fisica puo essere affiancata da metadati SharePoint per evitare duplicazioni.
