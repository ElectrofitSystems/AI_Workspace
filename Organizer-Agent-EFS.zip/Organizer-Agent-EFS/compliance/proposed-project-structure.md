# Struttura ibrida proposta per progetto

Questa struttura e una mappa logica iniziale, non un albero da imporre. L'infrastruttura principale e ancora in evoluzione: Organizer deve prima inventariare dove vivono davvero le informazioni e poi collegarle ai domini V-cycle e Automotive SPICE 4.1.

## Livello logico

    <Project logical map>/
    |-- 00_INDEX/
    |-- 01_MAN_Management/
    |-- 02_REF_Reference_Documentation/
    |-- 03_SYS_System_Engineering/
    |-- 04_DEV_Development/
    |-- 05_VER_Verification_and_Validation/
    |-- 06_SUP_Support_Processes/
    |-- 07_SPL.2_Releases/
    +-- 99_Archive/  [opzionale]

## Infrastruttura fisica ammessa

I contenuti possono restare in cartelle Teams o SharePoint gia esistenti, repository di codice, liste, OneNote, strumenti ALM, sistemi di test o altre fonti controllate. 00_INDEX mantiene i riferimenti, non copie inutili.

| Area logica | Collegamento indicativo | Collocazione fisica |
|---|---|---|
| 00_INDEX | Responsabile, perimetro, repository, piano, baseline, indice evidenze | Cartella indice del progetto o lista SharePoint |
| 01_MAN | MAN.3, MAN.5, MAN.6 | Struttura corrente di project management |
| 02_REF | Datasheet, cataloghi e manuali; REF e interno | Cartelle di riferimento esistenti |
| 03_SYS | SYS.1-SYS.5 | Requisiti, architettura e test di sistema nelle fonti correnti |
| 04_DEV | SWE.1-SWE.6, HWE.1-HWE.4; MLE.1-MLE.4 se applicabile | Repository e cartelle per disciplina |
| 05_VER | VAL.1 e verifiche SYS/SWE/HWE/MLE; VER e interno | Tool di test, risultati, report e matrici esistenti |
| 06_SUP | SUP.1, SUP.8, SUP.9, SUP.10; SUP.11 se applicabile | QA, configurazione, problemi, change e dati ML |
| 07_SPL.2 | Pacchetti, note ed evidenza di consegna | Area release controllata |
| 99_Archive | Solo storico identificato | Opzionale; non creato automaticamente |

## Regole di adozione

1. Inventariare la struttura reale e chiedere lo scopo di ogni cartella.
2. Registrare la posizione fisica e l'area logica senza spostare nulla.
3. Mappare information item e caratteristiche ai work product reali con relazione molti-a-molti.
4. Segnalare gap, duplicazioni e ambiguita.
5. Proporre il minimo cambiamento fisico necessario.
6. Spostare o creare cartelle solo dopo approvazione umana.
7. Conservare link, baseline, versioni e storia delle decisioni.

MAN, SYS, SWE, HWE, MLE, VAL, SUP e SPL.2 richiamano Automotive SPICE 4.1. REF, DEV e VER sono codici organizzativi interni.
