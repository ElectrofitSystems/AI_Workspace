# Mappa iniziale Automotive SPICE 4.1

Fonte: Automotive SPICE Process Assessment / Reference Model, Version 4.1, Released, 2026-08-24. La guida non e inclusa nel pacchetto e deve essere ottenuta dal canale ufficiale VDA QMC.

| Categoria | Processi iniziali da configurare |
|---|---|
| Acquisition e Supply | ACQ.4, SPL.2 |
| System Engineering | SYS.1-SYS.5 |
| Validation | VAL.1 |
| Software Engineering | SWE.1-SWE.6 |
| Machine Learning Engineering | MLE.1-MLE.4 |
| Hardware Engineering | HWE.1-HWE.4 |
| Supporting | SUP.1, SUP.8, SUP.9, SUP.10, SUP.11 |
| Management | MAN.3, MAN.5, MAN.6 |
| Improvement e Reuse | PIM.3, REU.2 |

## Nota di versione 4.1

La cronologia ufficiale indica la rimozione di MLE.2 BP5 e modifiche editoriali basate sul feedback della comunita. Organizer non deve quindi aspettarsi o richiedere MLE.2 BP5.

## Regola di mappatura

Gli information item guidano la ricerca delle evidenze, ma non equivalgono necessariamente ai work product eFitSys. Un singolo work product puo coprire piu caratteristiche e la stessa caratteristica puo essere distribuita in piu output. La mappatura dipende dal contesto e richiede conferma dei responsabili.

Il perimetro effettivo, gli equivalenti aziendali e le responsabilita devono essere registrati in Configuration.
