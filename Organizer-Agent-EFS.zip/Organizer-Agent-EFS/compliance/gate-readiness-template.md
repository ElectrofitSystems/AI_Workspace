# Gate readiness report

- Progetto:
- Prodotto e variante:
- Gate:
- Baseline:
- Responsabile del gate:
- Data:

| Criterio | Stato | Evidenza | Responsabile | Decisione richiesta |
|---|---|---|---|---|
| | | | | |

## Decisione umana

- Esito:
- Decisore:
- Riferimento approvazione:
- Azioni aperte:
