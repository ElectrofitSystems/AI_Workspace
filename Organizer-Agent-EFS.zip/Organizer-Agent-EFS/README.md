# Organizer Agent EFS

Pacchetto locale di consegna per Operations. Non installa automaticamente l'agente e non attiva connessioni o flussi.

## Contenuto

- agent/: definizione bilingue dell'agente.
- skills/: dieci skill operative, incluse tracciabilita V-cycle, evidenze Automotive SPICE e baseline/rilasci.
- installer/: installazione guidata, configurazione e guida Power Automate.
- documentation/: report tecnico e presentazione di una pagina.
- diagrams/: illustrazione del flusso.
- compliance/: mappa iniziale dei processi, schema metadati e modelli di tracciabilita e gate readiness.
- MANIFEST.sha256: impronte dei file consegnati.

## Avvio per Operations

Leggere prima documentation/Organizer-EFS-Report-Tecnico.pdf, poi seguire installer/installer.md. Le azioni devono essere eseguite nel tenant EFS sotto supervisione e approvazione umana.
