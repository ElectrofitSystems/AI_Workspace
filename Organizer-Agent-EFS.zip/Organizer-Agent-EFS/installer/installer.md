# Installer guidato - Organizer Agent EFS

Procedura Codex guidata, non programma Windows. Il pacchetto non installa nÃ© attiva nulla finchÃ© Operations non avvia questa procedura.

## Fasi

1. Scegliere progetto Codex dedicato o esistente.
2. Verificare Team Administrator, canale Operations e permessi.
3. Approvare struttura e scopo delle cartelle.
4. Registrare chat approvazioni e identitÃ  non umane.
5. Definire il perimetro V-cycle e Automotive SPICE 4.0: SYS, SWE, HWE, processi di supporto, livello obiettivo e responsabili.
6. Confermare la mappa tra work product eFitSys, gate, baseline e regole di tracciabilita.
7. Installare agente e dieci skill.
8. Configurare trigger Teams.
9. Configurare schedule interne di 24 ore.
10. Creare i flussi Power Automate sotto supervisione.
11. Testare con materiale non sensibile e un progetto pilota.
12. Attivare dopo esito positivo.
13. Proporre il pilot di riorganizzazione.

## Domande V-cycle e Automotive SPICE

- Quali discipline sono nel perimetro: sistema, software, hardware?
- Quale capability level e un obiettivo aziendale, senza trasformarlo in dichiarazione dell'agente?
- Quali documenti eFitSys realizzano i work product dei processi selezionati?
- Chi sono Process Owner, responsabili tecnici, Quality e approvatori dei gate?
- Quali baseline, naming convention, strumenti ALM e matrici di tracciabilita esistono gia?
- Quali gate collegano requisiti, architettura, implementazione, integrazione, verifica, validazione e rilascio?

## Criteri di accettazione

- Un allegato arriva in Inbox una sola volta.
- La risposta dell'autore cancella la schedule corretta.
- La schedule scaduta inoltra solo dubbi aperti.
- Un bot non puÃ² approvare.
- Approva porta il file in Approved e poi alla destinazione.
- Mantieni in Review non sposta nÃ© cancella.
- Cancella richiede una persona e produce un log.
- I materiali riservati non arrivano a Marketing.

- Un work product senza processo, baseline, responsabile o collegamento richiesto viene segnalato, non approvato automaticamente.
- Un evidence package distingue evidenza presente, mancante e non verificata.
- Nessun report usa ASPICE compliant o assegna capability level senza decisione di un assessor autorizzato.

## Prima struttura proposta per progetto

Usare come punto di partenza compliance/proposed-project-structure.md. 00_INDEX, MAN, REF, SYS, DEV, VER, SUP e SPL.2 devono essere confermati dai moderatori. 99_Archive e opzionale e non viene creato automaticamente.
