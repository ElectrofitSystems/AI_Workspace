# Power Automate - flussi minimi

| Flusso | Trigger | Azione | Controllo |
|---|---|---|---|
| Intake | Allegato in chat Operations | Copia in 00_Inbox | ID univoco |
| Approval | Richiesta Organizer | Teams Approvals | Risposta umana |
| Transfer | File in 02_Approved | Sposta alla destinazione | Percorso verificato |
| Delete | Decisione esplicita | Elimina file specifici | Log obbligatorio |
| Logging | Esito dei flussi | Scrive in Logs | Idempotenza |
| Evidence index | Work product approvato o baselined | Aggiorna indice evidenze | Nessuna valutazione tecnica automatica |
| Traceability check | Nuovo collegamento o nuova baseline | Controlla riferimenti mancanti | Segnalazione, mai approvazione |

Computer Use puÃ² guidare la creazione online sotto supervisione. La schedule di 24 ore e il trigger di risveglio Teams non appartengono a Power Automate.

I flussi ASPICE registrano riferimenti e stati, non assegnano capability level e non dichiarano conformita. Aggiornare una baseline o una matrice approvata richiede identita umana e log della decisione.
